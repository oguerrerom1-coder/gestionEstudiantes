package co.edu.ucentral.manejadorUniveridades;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ManejadorUniveridadesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ManejadorUniveridadesApplication.class, args);
	}

}
