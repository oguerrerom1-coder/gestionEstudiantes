package co.edu.ucentral.manejadorUniveridades;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManejadorUniveridadesApplicationTests {

	@Test
	void contextLoads() {
	}

}
